Khang Bui
5215264

Project 0
1/22/14

Scanner:
The Scanner works fine and passes all tests that I could think of. I used two seperate Vectors one for the token string and the other for the token_type. I kept track of tokens using an index integer for both vectors

-- Parser
After a lot of frustration, I have decided to give up on the parser. Everything went well until I reached the non-terminal Expression. From that point on, I struggled to write the correct parsing language. I did my best to demonstrate how I felt each case for the non-terminal Expression should be handled, as well as how I felt recursion should be handled. I did my best on the parser but it was to no avail.
