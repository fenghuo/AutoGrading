#include <stdio.h>
#include <math.h>

int main()
{
    int m[101];

    m[pow(0, 1)] = pow(5, 1);

    m[pow(1, 1)] = pow(2, 1);

    m[pow(10, 1)] = pow(3, 1)*pow(5, 1);

    m[pow(100, 1)] = pow(5, 1) + pow((pow(6, 1)), 1);

    m[pow(50, 1)] = pow(5, 1) + pow((pow(4, 1) - pow(6, 1)), 1);

    m[pow(51, 1)] = pow(4, 1) - pow(6, 1);

    m[pow(0, 1)] = pow(5, 1) - pow((pow(4, 1) - pow(6, 1)), 1);

    m[pow(60, 1)] = pow(4, 1);

line1: ;

    m[pow(60, 1)] = pow(m[pow(60, 1)], 1) - pow(1, 1);

    m[pow(0, 1)] = pow(5, 1)/pow(2, 1)*pow(3, 1);

    m[pow(4, 1)] = pow(2, 1) + pow(2, 1);

    m[pow(0, 1)] = pow(5, 1) - pow((pow(m[pow(4, 1)], 1) - pow(6, 1)), 1);

    m[pow(0, 1)] = pow(5, 1)/pow(2, 1)*pow(3, 1);

    m[pow(0, 1)] = pow(2, 1) + pow(m[pow(2, 1)], 1);

    m[pow(0, 1)] = pow(5, 1) - pow(m[pow(4, 1) - pow(6, 1)], 1);

    m[pow(3, 1)] = pow(5, 1) - pow((pow(4, 1) - pow(6, 1)), 1);

    m[pow(2, 1)] = pow(5, 1) - pow(m[pow((pow(6, 1) - pow(4, 1)), 1)], 1);

    m[pow(2, 1)] = pow(m[pow(m[pow(3, 1)], 1)], 1);

    printf("%d", pow(m[pow(3, 1)], 1) );

    if ( pow(m[pow(60, 1)], 1) ) goto line1;
;

    printf("%d", pow(m[pow(2, 1)], 1) );

    goto line2;

    printf("%d", pow(m[pow(0, 1)], 1) );

line2: ;

    printf("%d", pow(m[pow(0, 1)], 1) );

    return 0;
}
