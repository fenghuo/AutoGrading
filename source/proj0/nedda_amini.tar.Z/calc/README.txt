Nedda Amini
5114517
Code Buddy : Sam Dacanay

Got the scanner to work for the most part, however I didn't have enough time to finish the parser. Family emergency required me to leave town.
Have a bit of trouble with this bison, but for the most part I understand what to do. 
My scanner is half way finished, but I think my language is correct
