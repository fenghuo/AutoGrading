Arlene Budiardjono
5509914

Notes:

IMPORTANT: for some reason, make input won't compile my c code correctly. use "gcc input.c -lm input" and it should work.

the c code is printed to standard err in the parser. All the functions return a string and they build upon each other to have the correct format.

I had a bit of trouble with the enums. For some reason strcpy really messed up my graph for certain strings.
