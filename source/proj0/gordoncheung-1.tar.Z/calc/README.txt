Gordon Cheung
5849039

Hi, the project should be fully functional except for the Power function when converting to C code.

The scanner is working, I have tested it many times. The cerr from the parser to emit the C-code causes some output in the command line when running the file though. I believe I have the correct errors thrown as well.

The parser also should work and throws the proper errors.


