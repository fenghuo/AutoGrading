CS 160 Winter 2014
Project 0 - calc

Student: Shayon Javadizadeh
Perm: 5643515

NOTES:

Currently, power is not working properly, specifically it will not work if there is a quantity that you are trying to power. So 5 ** 6 works, but (5+1) ** 6 does not work.
