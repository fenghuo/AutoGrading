#include <stdio.h>
#include <math.h>

int main(){
int m[101];
m[0] = 5 + 3 * 4 pow(4,55) + 3 * 5;
m[1 + 2 / ( 3 / 4 )] = 2;
m[100] = 5 + ( 6 ) + 4 / 5 / 8 + ( 3 / 4 );
printf("%d\n",m[3]);
m[50] = 5 + ( 4 - 6 );
printf("%d\n",4);
m[40] = 5 - ( 4 - 6 );
m[60 * 3 pow(3,44) * 3 * 2] = 4 * 4 pow(4,55) pow(5,33);
L1:
m[3] = 4;
m[3] = 5 - ( 4 - 6 );
m[( 3 / 455 ) + ( 533 / 6 ) - ( 8 - 33 )] = 5 - m[( 6 - 4 ) + ( 3 - 4 )];
m[2] = m[m[3]];
 if( m[60]){
     goto L1;
    }
L2:
printf("%d\n",m[0]);
 if( m[543545]){
     goto L3;
    }
 if( m[50]){
     goto L4;
    }

return 0;
  }