Sam Dacanay 4893582 1/22/14 for CS160 Winter Q 2014

I only was able to implement the scanner class in time. I need to come in to office hours to learn more about the fundamentals of recursive descent, I'm pretty confused about it. 

I did however try to fix the grammar for precedence, and put that in the .y file. 

I'm hoping to implement the parser later this week for no credit and run it passed the TAs to see if I'm doing anything right.

Thanks for your time.
