Daniel Razavi
4134953
CS160 Project 0

My project does not work completely. As of now, the scanner seems to scan and 
store the tokens properly with my single line tests. It does not keep track of 
new lines however. I believe my modified grammer is mostly correct, but I think 
the main problem is with how "Statements" is handled. It can be viewed in the 
Bison file. My parse class was implemented as such. Since I could not get these
working, I could not get the correct error lines or C code output.
