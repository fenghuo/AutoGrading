CS160 Project 0
David Truong #5843115

Quick Guide:
Compile with "make test_parse" and "make generate_code". Ignore the output on the console. The useful information is only located within files.  Error messages are printing to stdout and are located inside the .dot file at the very bottom.  This is because the .dot information and the error messages are printed to the same stream (stdout).  C++ Code is outputted to the stderr which is then redirected to a file called CCode.cpp. Parse tree is created as .pdf file.  

 
***************************************
The warning "warning: <stdin>: syntax error in line _ near ';'" appears when I compile the code. I believe this error is due to the way the .dot files and parsetree are created.  If you get the warning, you will notice that the line number that the warning gives corresponds to the last line of the produced .dot file where the semincolon comes after the bracket. I dont believe that this warning affects the program in any major way as my program still scans, parser, etc.
***************************************

Compiling and Runnin:
Compile with "make test_parse" to create a ".dot" and ".pdf" of the parse tree.(rename the outputted file in the makefile if you wish). I edited the makefile to only handle one input file at a time and you can see my changes in the makefile that I submit with this project.  IGNORE the output to the console.  That is my "cerr" code for when I generate the C++ code.  There is no useful information that is outputted to console.  Error messages are outputted to stdout which is the .dot file.  CCode is run with "make generate_code" and the C++ code is in the specified .cpp file in the makefile.

Error Handling:
My errors will print out to the specified ".dot" file that is used to generate the parse tree because the provided errors messages print to stdout and that is where the dot data file is also outputted to.  I couldnt output the error messages to stderr because that is where I am outputting my generated c code. If there is a mismatch/syntax error, it will print out the message and line number at the bottom of the ".dot" file and the name is specified is the makefile.

Parse Tree:
The parse tree that is created is a ".pdf".  If you edit the makefile, you can name it whatever you want.  For my makefile, I edited it so that the pdf wouldnt get truncated when the tree got too large.  The default arguments in the makefile for creating the pdf wouldnt allow the parse tree to fit fully on the page. The parse tree handles multiple statements in a given input file.  The "start" node denotes the start of a new statement and the subtrees of that node are the statement itself. The parse tree shows the non-terminal derivations of the grammar and the leaf nodes at the bottom are the terminals of the statement.

Scanner:
In calc.cpp, in the "main()" function, I have commented out a section of code that can be used to test that my scanner is working by itself.  Uncomment the block of code and comment out the code that tests the parser to only test the scanner.  The scanner worked for all of my test cases so if for some reason, it doesnt scan at all, please take a look at the scanner_t class.

Parser and Grammar:
In calc_def.y, my grammar is defined and it is unambigous, LL(1), and handles precedence as well as the other cases defined in the language.  In calc.cpp, I implemented the grammar rules with respect to the first and follow sets of the non-terminals.  In calc.cpp, parser_t class, if the next token is not handled by the cases that can be encountered, then the token is not in the first or follow set and therefore is a syntax error which is outputted with line number and description.

Code Generation:
Use "make generate_code" to create a .cpp(name specified in makefile) with my attempt at generating c++ code. Cerr is used to generate the c++ code and the cerr statements are located in "main()" and throughout the parser class.
