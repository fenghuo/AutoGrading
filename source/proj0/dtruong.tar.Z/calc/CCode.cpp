#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <math.h>
using namespace std;
int main()
{
int m[100];
m[(num* * num) ) ) )**num] ] ] ] = num+ + + num* * num



Lnum:

goto num;

goto num if m[num] ] ] ]



print num* * (num+ + + num) ) ) )


return 0;
}
