My scanner is fully functioning and implemented, and I have at least all of the logic for my grammar to parce correctly.

