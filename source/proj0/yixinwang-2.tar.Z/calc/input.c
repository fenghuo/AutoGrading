#include <stdio.h>
#include <math.h>
 int main(){
 int m[101];
 int i=0;
 for(i=0;i<101;i++){
 m[i]=0;}
mmmm[[cc]]]]]==cc
mmmmmmmm[[cc]]]]]==cc
mmmmmmmm[[cc]]]]]==cc***cc
mmmmmmmm[[cc]]]]]==cc++++((cc)))))
mmmmmmmm[[cc]]]]]==cc++++((cc----cc)))))
mmmmmmmm[[cc]]]]]==cc----cc
mmmmmmmm[[cc]]]]]==cc----((cc----cc)))))
mmmmmmmm[[cc]]]]]==cc
LLLLLLLLcc::
mmmmm[[cc]]]]]==mm[[cc]]]]]----cc
mmmmmmmm[[cc]]]]]==cc///cc***cc
mmmmmmmm[[cc]]]]]==cc++++cc
mmmmmmmm[[cc]]]]]==cc----((mm[[cc]]]]]----cc)))))
mmmmmmmm[[cc]]]]]==cc///cc***cc
mmmmmmmm[[cc]]]]]==cc++++mm[[cc]]]]]
mmmmmmmm[[cc]]]]]==cc----mm[[cc----cc]]]]]
mmmmmmmm[[cc]]]]]==cc----((cc----cc)))))
mmmmmmmm[[cc]]]]]==cc----mm[[((cc----cc)))))]]]]]
mmmmmmmm[[cc]]]]]==mm[[mm[[cc]]]]]]]]]]
printfprintfprintfprintfprintfprintf()printfprintfmm[[cc]]]]]
gotogotogotogotogotogotogotogotoccififmm[[cc]]]]]
printfprintfprintfprintfprintfprintf()printfprintfmm[[cc]]]]]
gotogotogotogotogotogotogotogotocc
printfprintfprintfprintf()printfprintfmm[[cc]]]]]
LLLLLLLLcc::
printfprintfprintf()printfprintfmm[[cc]]]]]
return 0;}
