#include <iostream>
#include <math.h>
using namespace std;

int main() {
int m[101];
return 0;
}